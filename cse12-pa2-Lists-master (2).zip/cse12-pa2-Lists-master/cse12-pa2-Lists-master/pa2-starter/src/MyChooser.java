
public interface MyChooser<E> {
  boolean chooseElement(E e);
}
 