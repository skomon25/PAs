
public interface MyTransformer<E> {
	E transformElement(E e);
}